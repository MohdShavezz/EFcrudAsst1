﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class ShowEmployees
    {
        public ShowEmployees()
        {
            //foreach (var i in Employees)
            //{
            //    Console.WriteLine("{0} {1} {2} {3} {4}", i.ID, i.Name, i.Dept, i.Tech, i.CName);
            //}
            try
            {
                string ConString = "data source=SHAVEZ; database=EmployeeDBAsst1; integrated security=SSPI";
                using (SqlConnection connection = new SqlConnection(ConString))
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "select * from Employees";
                    cmd.Connection = connection;
                    // Opening Connection  
                    connection.Open();
                    // Executing the SQL query  
                    SqlDataReader sdr = cmd.ExecuteReader();
                    Console.WriteLine("---------------------------");
                    Console.WriteLine("Employee_Id     Name     Dept    Tech    Company");
                    while (sdr.Read())
                    {
                        Console.WriteLine(sdr["EmployeeId"] + ", " + sdr["Name"] + ", " + sdr["Dept"] + ", " + sdr["Tech"] + ", " + sdr["CName"]);
                    }
                    Console.WriteLine("---------------------------");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("OOPs, something went wrong.\n" + e);
            }
        }
    }
}
