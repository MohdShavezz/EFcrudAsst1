﻿using HelloWorld;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Delete
    {
        public Delete()
        {

            //Console.WriteLine("enter UserID to Delete: ");
            //Guid userIdDel = Guid.Parse(Console.ReadLine());
            Guid userIdDel = Guid.Empty;
            bool isValidGuid = false;
            string input;

            do
            {
                Console.Write("Enter EmpId to Delete ('quit' to go back): ");
                input = Console.ReadLine();

                if (input.ToLower() == "quit")
                {
                    return;
                }

                isValidGuid = Guid.TryParse(input, out Guid guid);

                if (!isValidGuid)
                    Console.WriteLine("Invalid GUID format. Please try again.");
                else
                    userIdDel=guid;
            }
            while (!isValidGuid);

            try
            {
                string ConString = "data source=SHAVEZ; database=EmployeeDBAsst1; integrated security=SSPI";
                using (SqlConnection connection = new SqlConnection(ConString))
                {
                    SqlCommand cmd = new SqlCommand($"DELETE from Employees WHERE EmployeeId='{userIdDel}'", connection);
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Deleted sucessfully..");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("OOPs, something went wrong.\n" + e);
            }

            Console.WriteLine("---------------------------");

        }
    }
}
