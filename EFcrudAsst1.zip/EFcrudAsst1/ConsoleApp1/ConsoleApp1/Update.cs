﻿using HelloWorld;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp1
{
    internal class Update
    {
        public Update()
        {
            Console.WriteLine("enter UserID to Update: ");
            Guid userID = Guid.Parse(Console.ReadLine());

            Console.WriteLine("enter Name : ");
            string userName = Console.ReadLine();
            userName = Validation.checkName(userName);
            if (userName == "quit")
            {
                return;
            }

            Console.WriteLine("enter Department : ");
            string userDept = Console.ReadLine();
            userDept = Validation.checkName(userDept);
            if (userName == "quit")
            {
                return;
            }

            Console.WriteLine("enter Technology : ");
            string userTech = Console.ReadLine();
            userTech = Validation.checkNullorEmpty(userTech);
            if (userName == "quit")
            {
                return;
            }

            Console.WriteLine("enter Company Name : ");
            string userComp = Console.ReadLine();
            userComp = Validation.checkNullorEmpty(userComp);
            if (userName == "quit")
            {
                return;
            }
            //foreach (var i in Employees.Where(emp => emp.ID == userID))
            //{
            //    i.Name = userName;
            //    i.Dept = userDept;
            //    i.Tech = userTech;
            //    i.CName = userComp;
            //}
            try
            {
                string ConString = "data source=SHAVEZ; database=EmployeeDBAsst1; integrated security=SSPI";
                using (SqlConnection connection = new SqlConnection(ConString))
                {
                    SqlCommand cmd = new SqlCommand($"UPDATE Employees SET  Name='{userName}',Dept='{userDept}',Tech='{userTech}',CName='{userComp}' WHERE EmployeeId='{userID}'", connection);
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Updated sucessfully..");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("OOPs, something went wrong.\n" + e);
            }


            Console.WriteLine("---------------------------");

        }
    }
}
