﻿using ConsoleApp1;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace HelloWorld
{
    
    public class Program
    {
        

        public static void addEmployee(Guid EmpId, string name, string dep, string tech, string cname)
        {
            
            try
            {
                //string ConString = "data source=SHAVEZ; database=linq_db; integrated security=SSPI";
                //using (SqlConnection connection = new SqlConnection(ConString))
                //{
                //    SqlCommand cmd = new SqlCommand();
                //    cmd.CommandText = $"INSERT INTO Employee VALUES ('{EmpId}','{name}', '{dep}', '{tech}', '{cname}')";
                //    cmd.Connection = connection;
                //    connection.Open();
                //    // Executing the SQL query  
                //    cmd.ExecuteNonQuery();
                //    Console.WriteLine("inserted successfully...");
                //}
                using (var ctx = new EmpContext())
                {
                    var stud = new Employee() { EmployeeId=EmpId, Name = name, Dept = dep, Tech = tech, CName = cname };
                    ctx.Employees.Add(stud);
                    ctx.SaveChanges();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("OOPs, something went wrong.\n" + e);
            }
        }

        public static void Main(string[] args)
        {
            // Print Employees Table
            //new ShowEmployees();
            Console.WriteLine("---------------------------");


            while (true)
            {
                Console.WriteLine("Show All : type s");
                Console.WriteLine("Add : press a");
                Console.WriteLine("Update : press u");
                Console.WriteLine("Delete : press d");
                Console.WriteLine("Exit : press e");
                string usrChoice = Console.ReadLine();
                if (usrChoice == "a")
                {
                    // add Employee
                    new Add();
                }
                else if (usrChoice == "u")
                {
                    // Update Row
                    new Update();
                }
                else if (usrChoice == "d")
                {
                    // Delete Row
                    new Delete();

                }
                else if (usrChoice == "s")
                {
                    new ShowEmployees();
                }
                else if (usrChoice == "e")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("invalid input");
                }
            }




        }
    }
}